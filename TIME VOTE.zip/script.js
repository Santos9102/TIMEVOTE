document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById('votacaoForm');
    const resultado = document.getElementById('resultado');
    const justificativa = document.getElementById('justificativa');
    const eliminacaoDisplay = document.createElement('p');
    document.body.appendChild(eliminacaoDisplay);

    const times = {
        "Bahia": 0,
        "Vasco": 0,
        "Flamengo": 0,
        "Grêmio": 0,
        "Fluminense": 0,
        "Corinthians": 0,
        "Botafogo": 0,
        "São Paulo": 0,
        "Santos": 0,
        "Atlético Mineiro": 0,
        "EC Vitória": 0
    };

    const hoje = new Date().toLocaleDateString();
    
    // Checar se o usuário já votou hoje
    if (localStorage.getItem('votoDia') === hoje) {
        resultado.textContent = "Você já votou hoje. Tente novamente amanhã!";
        form.style.display = "none";
        return;
    }

    // Lidar com o envio do formulário
    form.addEventListener("submit", function(event) {
        event.preventDefault();
        
        const timeEscolhido = form.elements["time"].value;
        const justificativaTexto = justificativa.value;

        if (!timeEscolhido) {
            alert("Por favor, escolha um time para votar.");
            return;
        }

        // Incrementar o voto no time escolhido
        times[timeEscolhido]++;

        // Armazenar o voto para o dia
        localStorage.setItem('votoDia', hoje);

        // Exibir resultado temporário ao usuário
        resultado.textContent = `Você votou no ${timeEscolhido}! Obrigado pelo seu voto.`;

        // Aqui você pode enviar o voto e a justificativa para um backend (servidor) usando AJAX ou uma API
        console.log(`Voto no time: ${timeEscolhido}. Justificativa: ${justificativaTexto}`);

        form.style.display = "none";
    });

    // Função para eliminar o time com mais votos no final do dia
    function eliminarTimeComMaisVotos() {
        let maxVotos = -1;
        let timeComMaisVotos = '';

        for (let time in times) {
            if (times[time] > maxVotos) {
                maxVotos = times[time];
                timeComMaisVotos = time;
            }
        }

        // Remover o time com mais votos
        delete times[timeComMaisVotos];
        
        // Exibir o time eliminado e seus votos
        eliminacaoDisplay.textContent = `O time ${timeComMaisVotos} foi eliminado com ${maxVotos} votos!`;

        // Se restarem apenas três times, atribuir medalhas
        atribuirMedalhas();
    }

    // Função para atribuir medalhas ao final do campeonato
    function atribuirMedalhas() {
        const timesRestantes = Object.keys(times);
        if (timesRestantes.length === 3) {
            // Determinar os vencedores
            let primeiroLugar = timesRestantes[0];
            let segundoLugar = timesRestantes[1];
            let terceiroLugar = timesRestantes[2];

            document.body.innerHTML += `<p class="medalha">🥇 1º Lugar: ${primeiroLugar}</p>`;
            document.body.innerHTML += `<p class="medalha">🥈 2º Lugar: ${segundoLugar}</p>`;
            document.body.innerHTML += `<p class="medalha">🥉 3º Lugar: ${terceiroLugar}</p>`;
        }
    }

    // Simular a eliminação do time mais votado diariamente (você pode fazer isso em um servidor)
    setInterval(eliminarTimeComMaisVotos, 86400000); // Elimina o time uma vez por dia (86.400.000ms = 24h)
});